from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,xml.etree.ElementTree as E,os,re,subprocess
os.umask(0o077)
r=Path('/Users/danny/Documents/UIC/CS441/ScholarChain');w=Path('/private/tmp/scholarchain-phase12d-spark-build-runtime-20261103')
result=json.loads((w/'fullcheck-attempt2-result.json').read_text());assert result['exit']==0
f=json.loads((w/'fullcheck-attempt2-source-freeze.json').read_text());sha=lambda d:hashlib.sha256(d).hexdigest()
assert all(sha((r/x['path']).read_bytes())==x['sha256'] and len((r/x['path']).read_bytes())==x['bytes'] for x in f['files'])
job=r/'modules/spark/target/spark-job_3-0.1.0-SNAPSHOT.jar';assert sha(job.read_bytes())==f['job_jar_sha256']
t=(w/'fullcheck-attempt2.log.txt').read_text(errors='replace');counts=list(map(int,re.findall(r'Total number of tests run: (\d+)',t)))
assert len(counts)==9 and counts[:8]==[207,64,39,50,80,107,40,667]
assert not any('*** FAILED ***' in x or '*** ABORTED ***' in x for x in t.splitlines())
assert '[error] (checkProbeInjectFailure) scholarchain check probe: injected format-stage failure' in t
assert '[info] - checkTask aborts before markTestRun when an earlier step fails' in t
marker=r/'.claude/.last-test-run';md=marker.read_text();kv=dict(x.split('=',1) for x in md.strip().splitlines());assert kv['success']=='true'
cmd=json.loads((w/'fullcheck-attempt2-command.json').read_text());start=datetime.fromisoformat(cmd['start']).timestamp();end=datetime.fromisoformat(result['completed_at']).timestamp()
assert start<=int(kv['timestamp'])/1000<=end
assert 'running scholarchain.build.TestRunMarker' in t
xmlrows=[];dest=w/'fullcheck-attempt2-xml';dest.mkdir(mode=0o700)
for base in ['modules/core','modules/hadoop','modules/entity-resolution','modules/spark','modules/storage','modules/rag','modules/services','tests','build-verification']:
 for p in (r/base/'target/test-reports').glob('TEST-*.xml'):
  data=p.read_bytes();v=E.fromstring(data);rel=str(p.relative_to(r));q=dest/rel;q.parent.mkdir(parents=True,exist_ok=True)
  with q.open('xb') as o:o.write(data)
  xmlrows.append({'path':rel,'tests':int(v.get('tests',0)),'failures':int(v.get('failures',0)),'errors':int(v.get('errors',0)),'sha256':sha(data)})
assert sum(x['failures']+x['errors'] for x in xmlrows)==0
assert sum(x['tests'] for x in xmlrows)==sum(counts)
with (w/'fullcheck-attempt2-xml-summary.json').open('x') as o:json.dump({'files':xmlrows,'tests':sum(counts),'failures':0,'errors':0},o,indent=2);o.write('\n')
summary={'fullcheck_exit':0,'fullcheck_seconds':result['seconds'],'module_counts':dict(zip(['core','hadoop','entityResolution','sparkAnalytics','storage','rag','services','independentTests','buildVerification'],counts)),'fullcheck_tests':sum(counts),'failures':0,'errors':0,'XML_files':len(xmlrows),'XML_test_sum_matches_log':True,'source_files_unchanged_during_gate':len(f['files']),'same_packaged_job_jar_sha256':f['job_jar_sha256'],'test_marker_written_after_all_stages':True,'marker_timestamp':kv['timestamp'],'marker_bytes_sha256':sha(marker.read_bytes()),'packaged_artifact_before_fullcheck':'Candidate used for actual offline baselines; now gate validates unchangedsource/JAR retrospectively, not independentreview or releaseapproval.','expected_nested_checkFailurePath_injected_error':True,'postprocess_attempt1_error':'Overbroad parser rejected intentionally injected nested error; full outer gate itself exit0, corrected parser binds passing negative test and final marker.','build_source_edits':0,'dependency_version_changes':0,'AWS_calls':0,'private_reads':0,'completed_at':result['completed_at']}
with (w/'fullcheck-attempt2-summary.json').open('x') as o:json.dump(summary,o,sort_keys=True,indent=2);o.write('\n')
print(json.dumps(summary,sort_keys=True))
