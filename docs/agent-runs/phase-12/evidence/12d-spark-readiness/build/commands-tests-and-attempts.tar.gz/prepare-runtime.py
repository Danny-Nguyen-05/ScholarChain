from pathlib import Path
from datetime import datetime,timezone
import json,os,zipfile,hashlib,shutil
os.umask(0o077)
repo=Path('/Users/danny/Documents/UIC/CS441/ScholarChain');w=Path('/private/tmp/scholarchain-phase12d-spark-build-runtime-20261103')
root=repo/'target/phase12d-readiness-20261103/runtime';root.mkdir(mode=0o700)
home=root/'spark-home';(home/'jars').mkdir(mode=0o700,parents=True);(home/'conf').mkdir(mode=0o700);(home/'work').mkdir(mode=0o700)
job=repo/'modules/spark/target/spark-job_3-0.1.0-SNAPSHOT.jar'
sha=lambda d:hashlib.sha256(d).hexdigest()
jobbytes=job.read_bytes();jobsha=sha(jobbytes)
with zipfile.ZipFile(job) as z:
 jobclasses={x for x in z.namelist() if x.endswith('.class') and x.rsplit('/',1)[-1]!='module-info.class'}
 assert 'edu/uic/cs441/scholarchain/spark/Phase6Main.class' in jobclasses
 assert 'edu/uic/cs441/scholarchain/spark/Phase12Readiness.class' in jobclasses
 assert not any(x.startswith(('org/apache/spark/','org/apache/hadoop/','ch/qos/logback/')) for x in jobclasses)
 original_entries={x:z.read(x) for x in ['scala/Option.class','scala/deriving/Mirror.class']}
copy=home/'jars/000-scholarchain-job.jar'
with copy.open('xb') as f:f.write(jobbytes)
cp=(w/'spark-external-classpath.txt').read_text().strip().split(os.pathsep)
assert len(cp)>100 and len(cp)==len(set(cp))
rows=[];bundled=[];included=[];references=[]
probes={'spark':'org/apache/spark/SparkContext.class','scala-library':'scala/Option.class','scala-reflect':'scala/reflect/api/Universe.class','scala3-library':'scala/deriving/Mirror.class'}
for raw in cp:
 p=Path(raw);assert p.is_absolute() and p.is_file() and p.suffix=='.jar'
 assert not p.name.endswith('_2.12.jar') and '_2.12-' not in p.name
 data=p.read_bytes()
 with zipfile.ZipFile(p) as z:
  classes={x for x in z.namelist() if x.endswith('.class') and x.rsplit('/',1)[-1]!='module-info.class'}
  isbundled=bool(classes) and classes<=jobclasses
  row={'artifact':p.name,'resolved_path':str(p),'bytes':len(data),'sha256':sha(data),'class_count':len(classes),'all_classes_already_bundled':isbundled}
  for component,name in probes.items():
   if name in classes:
    references.append({'component':component,'className':name[:-6].replace('/','.'),'class_sha256':sha(z.read(name)),'resolved_artifact':p.name,'resolved_artifact_sha256':sha(data),'resolved_path':str(p),'bundled_class_matches':name in jobclasses and z.read(name)==original_entries.get(name)})
 if isbundled:bundled.append(row)
 else:
  target=home/'jars'/p.name;assert not target.exists();target.symlink_to(p)
  row['runtime_link']=str(target);included.append(row)
 rows.append(row)
assert len([x for x in references if x['component']=='scala-library'])==1
assert len([x for x in references if x['component']=='scala3-library'])==1
for component,expected in [('spark','spark-core_2.13-3.5.4.jar'),('scala-library','scala-library-2.13.14.jar'),('scala-reflect','scala-reflect-2.13.14.jar'),('scala3-library','scala3-library_3-3.3.4.jar')]:
 x=[x for x in references if x['component']==component];assert len(x)==1 and x[0]['resolved_artifact']==expected
 if component in ('scala-library','scala3-library'):assert x[0]['bundled_class_matches'] is True
assert 'scala-library-2.13.14.jar' in [x['artifact'] for x in bundled]
assert 'scala3-library_3-3.3.4.jar' in [x['artifact'] for x in bundled]
runtimecp=[str(job)]+[x['runtime_link'] for x in sorted(included,key=lambda x:x['artifact'])]
assert all(Path(x).suffix=='.jar' for x in runtimecp)
with (root/'driver-classpath.txt').open('x') as f:f.write(os.pathsep.join(runtimecp)+'\n')
manifest={'kind':'Local isolated runtime assembled from actual cached sbt Provided dependency classpath; NOT EMR distribution or upstream binary release','job_jar':{'path':str(job),'bytes':len(jobbytes),'sha256':jobsha,'isolated_executor_copy':str(copy),'copy_sha256':sha(copy.read_bytes())},'spark_home':str(home),'driver_classpath_file':str(root/'driver-classpath.txt'),'external_artifacts':rows,'excluded_bundled_user_libraries':bundled,'runtime_jars':len(included)+1,'target_class_artifact_reference':references,'no_loose_application_class_directories':True,'driver_job_jar_first':True,'scala_libraries_not_duplicated':True,'downloads':0,'AWS_calls':0,'prepared_at':datetime.now(timezone.utc).isoformat()}
with (root/'runtime-manifest.json').open('x') as f:json.dump(manifest,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'runtime_root':str(root),'job_jar_sha256':jobsha,'runtime_jars':len(included)+1,'excluded_bundled_dependency_jars':len(bundled),'manifest':str(root/'runtime-manifest.json')}))
