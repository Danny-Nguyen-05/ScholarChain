from pathlib import Path
from datetime import datetime,timezone
import os,subprocess,json,time,hashlib,signal,sys
w=Path('/private/tmp/scholarchain-phase12d-spark-build-runtime-20261103');repo=Path('/Users/danny/Documents/UIC/CS441/ScholarChain')
java='/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home'
env={'HOME':'/Users/danny','USER':'danny','LOGNAME':'danny','PATH':java+'/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','JAVA_HOME':java,'TMPDIR':'/private/tmp','LANG':'en_US.UTF-8','SPARK_LOCAL_IP':'127.0.0.1','SPARK_LOCAL_HOSTNAME':'127.0.0.1','AWS_EC2_METADATA_DISABLED':'true','SBT_OPTS':'-Dsbt.offline=true -Dsbt.supershell=false -Dlogback.configurationFile='+str(repo/'docs/agent-runs/phase-04/xml-repair-logback.xml')}
cmd=['/opt/homebrew/bin/sbt','-batch','set ThisBuild / offline := true','export hadoop/Compile/fullClasspath','export entityResolution/Compile/fullClasspath','sparkAnalytics/scalafmt','sparkAnalytics/Test/scalafmt','sparkAnalytics/Test/testOnly edu.uic.cs441.scholarchain.spark.Phase12ReadinessSpec']
start=datetime.now(timezone.utc);t=time.monotonic()
with (w/'targeted-attempt2-command.json').open('x') as f:json.dump({'command':cmd,'cwd':str(repo),'environment':env,'start':start.isoformat(),'timeout_seconds':1200},f,indent=2);f.write('\n')
with (w/'targeted-attempt2.log.txt').open('xb') as out:
 p=subprocess.Popen(cmd,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 try:rc=p.wait(timeout=1200)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=20)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  rc=124
text=(w/'targeted-attempt2.log.txt').read_text(errors='replace')
classpath_lines=[x for x in text.splitlines() if x.startswith('/') and '.jar' in x and ':' in x]
for name,line in zip(['hadoop-compile-classpath.txt','er-compile-classpath.txt'],classpath_lines):
 with (w/name).open('x') as f:f.write(line+'\n')
result={'exit':rc,'seconds':round(time.monotonic()-t,3),'classpath_lines_found':len(classpath_lines),'completed_at':datetime.now(timezone.utc).isoformat()}
with (w/'targeted-attempt2-result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
print('\n'.join(text.splitlines()[-30:]))
sys.exit(rc)
