# Read-only audit command erratum

The earlier build audit proposed `sbt -batch -offline ...`. Actual targeted attempt1 showed this installed launcher sends `-offline` to the sbt parser, which rejects it before compilation. That proposal is superseded.

Actual successful targeted attempt2 uses explicit JDK17, `SBT_OPTS=-Dsbt.offline=true -Dsbt.supershell=false ...`, and the first sbt command `set ThisBuild / offline := true`, followed by the requested task commands. It completed11tests,0failures,0errors,exit0. No dependency version was changed and no source defect was attributed to the launcher error. See retained exact command/result/log.

Fullcheck-package attempt1 uses the corrected launcher syntax and completed1253 module tests with one independent source-fence failure; it did not reach contractTest, markTestRun, packaging or runtime classpath export. The Spark owner is repairing that source-fence failure without changing the independent gate. No old JAR was used as a current runtime baseline.
