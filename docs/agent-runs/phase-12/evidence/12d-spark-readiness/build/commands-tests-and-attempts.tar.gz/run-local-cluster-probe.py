from pathlib import Path
from datetime import datetime,timezone
import os,subprocess,json,time,hashlib,signal,sys
repo=Path('/Users/danny/Documents/UIC/CS441/ScholarChain');w=Path('/private/tmp/scholarchain-phase12d-spark-build-runtime-20261103');root=repo/'target/phase12d-readiness-20261103'
runtime=root/'runtime';manifest=json.loads((runtime/'runtime-manifest.json').read_text());home=Path(manifest['spark_home'])
shared=root/'probe-shared';shared.mkdir(mode=0o700);outroot=root/'probe-results';outroot.mkdir(mode=0o700);output=outroot/'local-cluster-probe.json'
java='/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home'
env={'HOME':'/Users/danny','USER':'danny','LOGNAME':'danny','PATH':java+'/bin:/usr/bin:/bin','JAVA_HOME':java,'TMPDIR':'/private/tmp','LANG':'en_US.UTF-8','SPARK_LOCAL_IP':'127.0.0.1','SPARK_LOCAL_HOSTNAME':'127.0.0.1','SPARK_HOME':str(home),'SPARK_CONF_DIR':str(home/'conf'),'SPARK_WORKER_DIR':str(home/'work'),'AWS_EC2_METADATA_DISABLED':'true'}
modules=['java.base/java.lang','java.base/java.lang.invoke','java.base/java.lang.reflect','java.base/java.io','java.base/java.net','java.base/java.nio','java.base/java.util','java.base/java.util.concurrent','java.base/java.util.concurrent.atomic','java.base/jdk.internal.ref','java.base/sun.nio.ch','java.base/sun.nio.cs','java.base/sun.security.action','java.base/sun.util.calendar','java.security.jgss/sun.security.krb5']
opens=['--add-opens='+m+'=ALL-UNNAMED' for m in modules]
cp=(runtime/'driver-classpath.txt').read_text().strip();assert cp.split(os.pathsep)[0]==manifest['job_jar']['path']
cmd=[java+'/bin/java','-Xmx1g',*opens,'-Djava.net.preferIPv4Stack=true','-Dspark.ui.enabled=false','-Dspark.master=local-cluster[1,1,1024]','-Dspark.executor.memory=512m','-Dspark.executor.cores=1','-Dspark.cores.max=1','-Dspark.driver.host=127.0.0.1','-Dspark.driver.bindAddress=127.0.0.1','-Dspark.rpc.netty.dispatcher.numThreads=2','-Dspark.task.maxFailures=1','-Dspark.executor.extraJavaOptions='+' '.join(opens),'-Dspark.hadoop.fs.defaultFS=file:///','-cp',cp,'edu.uic.cs441.scholarchain.spark.Phase12Readiness','probe',str(shared),str(output),'distributed']
start=time.monotonic()
with (w/'local-cluster-probe-command.json').open('x') as f:json.dump({'command':cmd,'cwd':str(repo),'environment':env,'timeout_seconds':180,'started_at':datetime.now(timezone.utc).isoformat()},f,sort_keys=True,indent=2);f.write('\n')
with (w/'local-cluster-probe.log.txt').open('xb') as log:
 p=subprocess.Popen(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 timed=False;cleanup=[]
 try:rc=p.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(p.pid,signal.SIGTERM);cleanup.append('SIGTERM to owned process group after180s')
  try:p.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);cleanup.append('SIGKILL owned process group after15s grace');p.wait()
  rc=124
 # The driver can exit while a descendant is still unwinding; clean only this newly owned group.
 try:
  os.killpg(p.pid,0);os.killpg(p.pid,signal.SIGTERM);cleanup.append('SIGTERM remaining owned process group after driver exit')
  time.sleep(1)
  try:os.killpg(p.pid,0);os.killpg(p.pid,signal.SIGKILL);cleanup.append('SIGKILL remaining owned process group')
  except ProcessLookupError:pass
 except ProcessLookupError:pass
result={'exit':rc,'timed_out':timed,'seconds':round(time.monotonic()-start,3),'output_exists':output.is_file(),'cleanup':cleanup,'completed_at':datetime.now(timezone.utc).isoformat(),'cloud_compatibility_verified':False,'remote_shared_mount_verified':False}
if rc==0:
 data=json.loads(output.read_text());assert data['externalExecutorVerified'] is True and data['driverToTaskAndBackVerified'] is True and data['cloudCompatibilityVerified'] is False
 result['driver_pid']=data['driver']['pid'];result['executor_pid']=data['taskProcesses'][0]['pid'];result['executor_id']=data['taskProcesses'][0]['executorId'];result['separate_processes']=result['driver_pid']!=result['executor_pid']
 assert result['separate_processes'] is True
with (w/'local-cluster-probe-result.json').open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(result,sort_keys=True))
print('\n'.join((w/'local-cluster-probe.log.txt').read_text(errors='replace').splitlines()[-15:]))
sys.exit(rc)
