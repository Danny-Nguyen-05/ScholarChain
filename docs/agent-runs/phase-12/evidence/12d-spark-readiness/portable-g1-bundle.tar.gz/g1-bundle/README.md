# Synthetic G1 portable consumer bundle

All researcher labels A-J and works w1-w9 are synthetic test fixtures. Hadoop and disabled-LLM ER completed through unchanged pipeline entry points. Completion/manifests/export bytes are copied, never fabricated. Reuse these exact bytes at different absolute roots and instantiate physical Spark config paths separately. Use the same exact newly packaged job JAR and logical settings for baseline/remote comparison. The archive proves no cluster, cloud, shared mount, deadline, alert delivery or spend allowance.
